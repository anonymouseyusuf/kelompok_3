<?php

$lang["SMS Gateway"] = "SMS Gateway";
$lang["Auth ID / Username"] = "Auth ID / Username";
$lang["Auth Token / Password"] = "Auth Token / Password";
$lang["Phone Number/ Mask"] = "Phone Number/ Mask";
$lang["API ID (Clickatell only)"] = "API_ID (Clickatell seulement)";

$lang['SMTP Host'] = "SMTP Host";
$lang['SMTP Port'] = "SMTP Port ";
$lang['SMTP User'] = "SMTP User";
$lang['SMTP Password'] = "SMTP Password";


$lang["send notification to delayed members"] = "envoyer une notification aux membres retardés";
$lang["send notification"] = "envoyer une notification";
$lang["notification type"] = "Type de notification";
$lang["sending, please wait..."] = "envoi, s'il vous plaît patienter ...";


$lang["send sms/email notification"] = "envoyer des sms / email de notification";


$lang["message subject"] 			= "Objet du message";
$lang["message"] 					= "message";
$lang["notification"] 			    = "notification";
$lang["only notification"] 			= "seule la notification";
$lang["email and notification"] 	= "e-mail et la notification";
$lang["SMS and notification"] 		= "SMS et notification";





