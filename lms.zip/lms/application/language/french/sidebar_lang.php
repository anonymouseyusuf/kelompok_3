<?php

// admin sidebar
$lang["dashboard"] 				= "tableau de bord";
$lang["general settings"] 		= "réglages généraux";
$lang["books"] 					= "livres";
$lang["book categories"] 		= "catégories de livres";
$lang["member"]  				= "membre";
$lang["members"] 		 		= "des membres";
$lang["member types"] 			= "types de membres";
$lang['notification']			= 'notification';
$lang['SMS settings']			= 'Paramètres SMS';
$lang['email SMTP settings']	= 'paramètres email SMTP';
$lang["notify delayed members"]= "aviser les membres retardés";
$lang["circulation"] 		 	= "circulation";
$lang["circulation settings"] 	= "les paramètres de circulation";
$lang["issue & return"] 		= "question & retour";
$lang["daily read books"] 		= "livres de lecture quotidiennes";
$lang["requested books"] 		= "livres demandés";
$lang["report"] 				= "rapport";
$lang["fine report"] 			= "rapport de pénalitérapport de pénalité";
$lang["notification report"] 	= "Rapport de notification";

$lang["generate member ID"] 	= "générer membre ID";
