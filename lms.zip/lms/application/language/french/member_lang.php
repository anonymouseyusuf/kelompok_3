<?php

$lang["type id"]   = "Type id";
$lang["user type"] = "type d'utilisateur";
$lang["address"]   = "adresse";
$lang["change password"]   = "changer le mot de passe";


