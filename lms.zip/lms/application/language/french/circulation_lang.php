<?php
$lang["circulation"] 		 	= "circulation";
$lang["circulation settings"] 	= "les paramètres de circulation";
$lang["issue and return"] 		= "alloué et le retour";
$lang["issue & return"] 		= "alloué & retour";
$lang["circulation list"] 		= "liste de diffusion";
$lang['issue limit - days'] 	= 'allouer limite - jours';
$lang['issue limit - books'] 	= 'allouer limite - livres';
$lang['fine per day'] 			= 'amende par jour';
$lang['issue'] 					= 'allouer';
$lang['new issue'] 				= 'nouvelle allouer';
$lang['return'] 				= 'retour';
$lang["fine"] 				    = "peine";
$lang["penalty"] 				= "peine";

$lang['issue from date'] = "allouer de la date";
$lang['issue date'] = "Date allouer";
$lang['expire from date'] = "expiration de la date";
$lang['issue to date'] = "allouer à ce jour";
$lang['expire to date'] = "expirera à jour";
$lang['expiry date'] = "date d'expiration";
$lang['return date'] = "date de retour";
$lang['return from date'] = "partir de la date de retour";
$lang['return from to'] = "retour de à";

$lang["member search panel"]="Membre du panel de recherche";
$lang["member ID/name"]="membre ID / nom";
$lang["book ID/name"]="livre ID / nom";
$lang["current circulation"]="la circulation du courant";

$lang['issued'] = "alloué";
$lang['returned'] = "revenu";
$lang['expired and returned'] = "expiré et retourné";
$lang['expired & returned'] = "expiré et retourné";
$lang['expired and not returned'] = "expiré et pas retourné";
$lang['expired & not returned'] = "expiré ou pas retourné";



