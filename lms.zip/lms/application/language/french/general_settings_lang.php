<?php

// general settings
$lang["institute name"] = "Nom de l'Institut";
$lang["institute address"] = "Institut Adresse";
$lang["institute email"] = "Institut Email";
$lang["institute phone / mobile"] = "Institut Téléphone / Mobile";
$lang["logo"] = "logo";
$lang["favicon"] = "favicon";
$lang["language"] = "la langue";
$lang["time zone"] = "Fuseau horaire";
$lang["currency"] = "monnaie";
$lang["terms and conditions"] = "termes et conditions";
