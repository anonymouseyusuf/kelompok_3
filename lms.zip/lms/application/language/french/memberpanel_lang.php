<?php
$lang["my circulation history"] = "mon histoire de circulation";
$lang["my requested books"] = "mes livres demandés";
$lang["my notifications"] = "mes notifications";
$lang["request new book"] = "demander nouveau livre";
$lang["received at"] = "reçu à";
$lang["is returned"] = "est renvoyé"; // for admin panel actually
