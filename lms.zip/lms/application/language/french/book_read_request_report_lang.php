<?php
$lang["read - number of times"] = "lire - nombre de fois";
$lang["last read at"] = "dernière lecture au";
$lang["member name"] = "nom de membre";
$lang["notification report"] = "Rapport de notification";
$lang["memberwise fine report"] = "rapport de la peine de membre";
$lang["reject request"]="rejeter la demande";
$lang["cause of rejection"]="cause de rejet";






