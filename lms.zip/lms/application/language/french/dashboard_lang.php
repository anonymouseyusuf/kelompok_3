<?php

// dashboard
$lang['total issued books + expired but not returned books'] = 
"Total des livres émis + livres périmés mais pas retournés";
$lang['total issued'] = "total émis";
$lang['expired but not returned'] = "expiré, mais pas de retour";
$lang['overall report'] = "rapport global";
$lang['total number of books'] = "nombre total de livres";
$lang['total number of issued books'] = "nombre total de livres publiés";
$lang['total number of members'] = "nombre total de membres";
$lang["today's report"] = "le rapport d'aujourd'hui";
$lang["today's added books"] = "les livres ajoutés d'aujourd'hui";
$lang["today's issued books"] = "Les livres publiés aujourd'hui";
$lang["today's returned books"] = "Les livres renvoyés d'aujourd'hui";
$lang["today's added members"] = "ajoutées les membres actuels";
$lang["this month's added book"] = "Le livre de ce mois supplémentaire";
$lang["current month's report"] = "Le rapport du mois en cours";
$lang["this month's issued book"] = "question le livre de ce mois-ci";
$lang["this month's returned book"] = "Le livre de ce mois de retour";

$lang["this month's added member"] = "le membre de ce mois supplémentaire"; 

$lang["issued and returned report for last 12 months"] = "rapport publié et retourné pendant 12 derniers mois";
$lang["more information"] = "plus d'information";

/*morris*/
$lang['number total returned'] = "rendement total de nombre";
$lang['number total issued'] = "nombre total émis";


