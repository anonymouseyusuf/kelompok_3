<?php

$lang["SMS Gateway"] = "SMS Gateway";
$lang["Auth ID / Username"] = "Auth ID / Username";
$lang["Auth Token / Password"] = "Auth Token / Password";
$lang["Phone Number/ Mask"] = "Phone Number/ Mask";
$lang["API ID (Clickatell only)"] = "API_ID（仅适用于的Clickatell）";

$lang['SMTP Host'] = "SMTP Host";
$lang['SMTP Port'] = "SMTP Port ";
$lang['SMTP User'] = "SMTP User";
$lang['SMTP Password'] = "SMTP Password";


$lang["send notification to delayed members"] = "发送通知延迟成员";
$lang["send notification"] = "发送通知";
$lang["notification type"] = "通知类型";
$lang["sending, please wait..."] = "发送，请稍候...";


$lang["send sms/email notification"] = "发送短信/邮件通知";


$lang["message subject"] 			= "信息主题";
$lang["message"] 					= "信息";
$lang["notification"] 			    = "通知";
$lang["only notification"] 			= "仅通知";
$lang["email and notification"] 	= "电子邮件和通知";
$lang["SMS and notification"] 		= "短信和通知";





