<?php

// dashboard
$lang['total issued books + expired but not returned books'] = "总指配书+过期但不归还的书";
$lang['total issued'] = "共分配";
$lang['expired but not returned'] = "过期但不退还";
$lang['overall report'] = "总体报告";
$lang['total number of books'] = "图书总数";
$lang['total number of issued books'] = "分配的书籍总数";
$lang['total number of members'] = "成员总数";
$lang["today's report"] = "今天的报告";
$lang["today's added books"] = "今天的新添的书籍";
$lang["today's issued books"] = "今天的分配书";
$lang["today's returned books"] = "今天的归还的书";
$lang["today's added members"] = "今天的添加的成员";
$lang["this month's added book"] = "本月加入书";
$lang["current month's report"] = "本月的报告";
$lang["this month's issued book"] = "这个月的指定书";
$lang["this month's returned book"] = "本月返回书";

$lang["this month's added member"] = "本月加入会员"; 

$lang["issued and returned report for last 12 months"] = "分配并返回报告过去12个月";
$lang["more information"] = "更多信息";

/*morris*/
$lang['number total returned'] = "数总回报";
$lang['number total issued'] = "分配数量的总";

