<?php

// admin sidebar
$lang["dashboard"] 				= "仪表盘";
$lang["general settings"] 		= "常规设置";
$lang["books"] 					= "图书";
$lang["book categories"] 		= "书的类别";
$lang["member"]  				= "会员";
$lang["members"] 		 		= "会员";
$lang["member types"] 			= "会员类型";
$lang['notification']			= '通知';
$lang['SMS settings']			= '短信设置';
$lang['email SMTP settings']	= '电子邮件SMTP设置';
$lang["notify delayed members"]= "通知延迟成员";
$lang["circulation"] 		 	= "循环";
$lang["circulation settings"] 	= "循环设置";
$lang["issue & return"] 		= "分配和返回";
$lang["daily read books"] 		= "每天读的书";
$lang["requested books"] 		= "请求书";
$lang["report"] 				= "报告";
$lang["fine report"] 			= "细报告";
$lang["notification report"] 	= "通知报告";

$lang["generate member ID"] 	= "产生会员ID";
