<?php
$lang["read - number of times"] = "";
$lang["last read at"] = "读 - 次数";
$lang["member name"] = "成员名字";
$lang["notification report"] = "通知报告";
$lang["memberwise fine report"] = "会员点球报告";
$lang["reject request"]="拒绝请求";
$lang["cause of rejection"]="拒绝的原因";






