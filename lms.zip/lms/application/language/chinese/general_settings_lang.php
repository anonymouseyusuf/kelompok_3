<?php

// general settings
$lang["institute name"] = "学院名称";
$lang["institute address"] = "学院地址";
$lang["institute email"] = "学院现";
$lang["institute phone / mobile"] = "研究所电话/手机";
$lang["logo"] = "徽标";
$lang["favicon"] = "网站图标";
$lang["language"] = "语言";
$lang["time zone"] = "时区";
$lang["currency"] = "货币";
$lang["terms and conditions"] = "条款和条件";
