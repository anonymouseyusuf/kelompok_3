<?php
$lang["my circulation history"] = "我的循环历史";
$lang["my requested books"] = "我要求书";
$lang["my notifications"] = "我的通知";
$lang["request new book"] = "请新书";
$lang["received at"] = "在收到";
$lang["is returned"] = "返回"; // for admin panel actually
