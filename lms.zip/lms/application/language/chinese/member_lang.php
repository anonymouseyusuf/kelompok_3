<?php

$lang["type id"]   = "类型ID";
$lang["user type"] = "用户类型";
$lang["address"]   = "地址";
$lang["change password"]   = "更改密码";


