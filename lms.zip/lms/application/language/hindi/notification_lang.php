<?php

$lang["SMS Gateway"] = "SMS Gateway";
$lang["Auth ID / Username"] = "Auth ID / Username";
$lang["Auth Token / Password"] = "Auth Token / Password";
$lang["Phone Number/ Mask"] = "Phone Number/ Mask";
$lang["API ID (Clickatell only)"] = "API_ID (Clickatell केवल)";

$lang['SMTP Host'] = "SMTP Host";
$lang['SMTP Port'] = "SMTP Port ";
$lang['SMTP User'] = "SMTP User";
$lang['SMTP Password'] = "SMTP Password";


$lang["send notification to delayed members"] = "देरी के सदस्यों को सूचना भेज";
$lang["send notification"] = "अधिसूचना भेज";
$lang["notification type"] = "जानकारी प्रकार";
$lang["sending, please wait..."] = "भेज रहा है, कृपया प्रतीक्षा करें ...";


$lang["send sms/email notification"] = "एसएमएस / ईमेल सूचना भेज";


$lang["message subject"] 			= "संदेश विषय";
$lang["message"] 					= "संदेश";
$lang["notification"] 			    = "अधिसूचना";
$lang["only notification"] 			= "केवल अधिसूचना";
$lang["email and notification"] 	= "ईमेल और अधिसूचना";
$lang["SMS and notification"] 		= "एसएमएस और अधिसूचना";




