<?php
$lang["my circulation history"] = "मेरी संचलन इतिहास";
$lang["my requested books"] = "मेरा अनुरोध किताबें";
$lang["my notifications"] = "मेरे सूचनाएँ";
$lang["request new book"] = "नई किताब का अनुरोध";
$lang["received at"] = "पर प्राप्त";
$lang["is returned"] = "वापस आ रहा है"; // for admin panel actually
