<?php

$lang["type id"]   = "प्रकार आईडी";
$lang["user type"] = "उपयोगकर्ता का प्रकार";
$lang["address"]   = "पता";
$lang["change password"]   = "पासवर्ड बदलें";


