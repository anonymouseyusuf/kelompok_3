<?php
$lang["read - number of times"] = "पढ़ा - बार की संख्या";
$lang["last read at"] = "पर पिछले पढ़ें";
$lang["member name"] = "सदस्य का नाम";
$lang["notification report"] = "अधिसूचना रिपोर्ट";
$lang["memberwise fine report"] = "सदस्य जुर्माना रिपोर्ट";
$lang["reject request"]="अनुरोध को अस्वीकार";
$lang["cause of rejection"]="अस्वीकृति का कारण";






