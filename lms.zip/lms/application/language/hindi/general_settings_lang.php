<?php

// general settings
$lang["institute name"] = "संस्थान का नाम";
$lang["institute address"] = "संस्थान पता";
$lang["institute email"] = "संस्थान ईमेल";
$lang["institute phone / mobile"] = "संस्थान फोन / मोबाइल";
$lang["logo"] = "প্রতিষ্ঠানের लोगो";
$lang["favicon"] = "फ़ेविकॉन";
$lang["language"] = "भाषा";
$lang["time zone"] = "समय क्षेत्र";
$lang["currency"] = "मुद्रा";
$lang["terms and conditions"] = "नियम और शर्तें";
