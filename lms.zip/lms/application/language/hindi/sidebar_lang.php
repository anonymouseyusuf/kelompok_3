<?php

// admin sidebar
$lang["dashboard"] 				= "डैशबोर्ड";
$lang["general settings"] 		= "सामान्य सेटिंग्स";
$lang["books"] 					= "किताबें";
$lang["book categories"] 		= "पुस्तक श्रेणियाँ";
$lang["member"]  				= "सदस्य";
$lang["members"] 		 		= "सदस्यों";
$lang["member types"] 			= "सदस्य के प्रकार";
$lang['notification']			= "अधिसूचना";
$lang['SMS settings']			= "एसएमएस सेटिंग्स";
$lang['email SMTP settings']	= "ईमेल एसएमटीपी सेटिंग्स";
$lang["notify delayed members"]= "विलंबित सदस्यों को सूचित";
$lang["circulation"] 		 	= "प्रसार";
$lang["circulation settings"] 	= "सर्कुलेशन सेटिंग्स";
$lang["issue & return"] 		= "मुद्दे और वापसी";
$lang["daily read books"] 		= "दैनिक पढ़ें पुस्तकें";
$lang["requested books"] 		= "अनुरोध किया पुस्तकें";
$lang["report"] 				= "रिपोर्ट";
$lang["fine report"] 			= "ललित रिपोर्ट";
$lang["notification report"] 	= "अधिसूचना रिपोर्ट";

$lang["generate member ID"] 	= "सदस्य आईडी उत्पन्न";
