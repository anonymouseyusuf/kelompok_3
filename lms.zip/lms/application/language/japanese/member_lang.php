<?php

$lang["type id"]   = "タイプID";
$lang["user type"] = "ユーザータイプ";
$lang["address"]   = "住所";
$lang["change password"]   = "パスワードを変更する";


