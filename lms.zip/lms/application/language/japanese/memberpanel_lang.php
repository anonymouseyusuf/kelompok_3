<?php
$lang["my circulation history"] = "私の循環歴史";
$lang["my requested books"] = "私の要求図書";
$lang["my notifications"] = "私の通知";
$lang["request new book"] = "新しい本をリクエスト";
$lang["received at"] = "で受信";
$lang["is returned"] = "返されます"; // for admin panel actually
