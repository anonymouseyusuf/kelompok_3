<?php
$lang["read - number of times"] = "読み - 回数";
$lang["last read at"] = "で最後の読み取り";
$lang["member name"] = "メンバー名";
$lang["notification report"] = "通知レポート";
$lang["memberwise fine report"] = "メンバーペナルティレポート";
$lang["reject request"]="要求を拒否";
$lang["cause of rejection"]="拒絶反応の原因";






