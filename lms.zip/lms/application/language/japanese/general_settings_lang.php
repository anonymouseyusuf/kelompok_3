<?php

// general settings
$lang["institute name"] = "研究所の名前";
$lang["institute address"] = "研究所住所";
$lang["institute email"] = "研究所のメール";
$lang["institute phone / mobile"] = "協会電話/携帯電話";
$lang["logo"] = "ロゴ";
$lang["favicon"] = "ファビコン";
$lang["language"] = "言語";
$lang["time zone"] = "タイムゾーン";
$lang["currency"] = "通貨";
$lang["terms and conditions"] = "規約と条件";
