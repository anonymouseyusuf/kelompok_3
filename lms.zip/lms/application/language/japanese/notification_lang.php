<?php

$lang["SMS Gateway"] = "SMS Gateway";
$lang["Auth ID / Username"] = "Auth ID / Username";
$lang["Auth Token / Password"] = "Auth Token / Password";
$lang["Phone Number/ Mask"] = "Phone Number/ Mask";
$lang["API ID (Clickatell only)"] = "API_ID（Clickatellのみ）";

$lang['SMTP Host'] = "SMTP Host";
$lang['SMTP Port'] = "SMTP Port ";
$lang['SMTP User'] = "SMTP User";
$lang['SMTP Password'] = "SMTP Password";


$lang["send notification to delayed members"] = "遅延メンバーに通知を送信";
$lang["send notification"] = "通知を送信";
$lang["notification type"] = "通知種別";
$lang["sending, please wait..."] = "送信、お待ちください...";


$lang["send sms/email notification"] = "SMS / Eメール通知を送信";


$lang["message subject"] 			= "メッセージの件名";
$lang["message"] 					= "メッセージ";
$lang["notification"] 			    = "お知らせ";
$lang["only notification"] 			= "のみ通知";
$lang["email and notification"] 	= "電子メールや通知";
$lang["SMS and notification"] 		= "SMSおよび通知";





