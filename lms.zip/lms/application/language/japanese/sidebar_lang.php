<?php

// admin sidebar
$lang["dashboard"] 				= "ダッシュボード";
$lang["general settings"] 		= "一般設定";
$lang["books"] 					= "図書";
$lang["book categories"] 		= "書籍のカテゴリ";
$lang["member"]  				= "メンバー";
$lang["members"] 		 		= "メンバー";
$lang["member types"] 			= "メンバータイプ";
$lang['notification']			= "お知らせ";
$lang['SMS settings']			= "SMSの設定";
$lang['email SMTP settings']	= "電子メールのSMTP設定";
$lang["notify delayed members"]= "遅延メンバーに通知";
$lang["circulation"] 		 	= "サーキュレーション";
$lang["circulation settings"] 	= "循環設定";
$lang["issue & return"] 		= "問題＆リターン";
$lang["daily read books"] 		= "毎日読んだ本";
$lang["requested books"] 		= "要求された書籍";
$lang["report"] 				= "報告する";
$lang["fine report"] 			= "ペナルティレポート";
$lang["notification report"] 	= "通知レポート";

$lang["generate member ID"] 	= "会員IDを生成します";
