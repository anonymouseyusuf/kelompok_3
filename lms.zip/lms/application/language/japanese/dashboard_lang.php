<?php

// dashboard
$lang['total issued books + expired but not returned books'] = "総発行書籍+期限切れのではなく、返された書籍";
$lang['total issued'] = "総発行";
$lang['expired but not returned'] = "有効期限が切れたが返されません";
$lang['overall report'] = "全体的なレポート";
$lang['total number of books'] = "本の総数";
$lang['total number of issued books'] = "発行された本の総数";
$lang['total number of members'] = "メンバーの合計数";
$lang["today's report"] = "今日の報告";
$lang["today's added books"] = "今日追加された書籍";
$lang["today's issued books"] = "今日発行された書籍";
$lang["today's returned books"] = "今日の返却図書";
$lang["today's added members"] = "今日追加されたメンバー";
$lang["this month's added book"] = "今月の追加の本";
$lang["current month's report"] = "現在の月の報告書";
$lang["this month's issued book"] = "今月号の本";
$lang["this month's returned book"] = "今月の返さブック";

$lang["this month's added member"] = "今月の追加メンバー"; 

$lang["issued and returned report for last 12 months"] = "過去12ヶ月の発行と返されたレポート";
$lang["more information"] = "詳しくは";

/*morris*/
$lang['number total returned'] = "数トータル・リターン";
$lang['number total issued'] = "数の合計が発行され";




