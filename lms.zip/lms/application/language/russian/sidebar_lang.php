<?php

// admin sidebar
$lang["dashboard"] 				= "панель приборов";
$lang["general settings"] 		= "общие настройки";
$lang["books"] 					= "книги";
$lang["book categories"] 		= "книги категории";
$lang["member"]  				= "член";
$lang["members"] 		 		= "члены";
$lang["member types"] 			= "типы члены";
$lang['notification']			= "уведомление";
$lang['SMS settings']			= "настройки SMS";
$lang['email SMTP settings']	= "";
$lang["notify delayed members"]= "уведомить пользователей отложенных";
$lang["circulation"] 		 	= "циркуляция";
$lang["circulation settings"] 	= "настройки циркуляции";
$lang["issue & return"] 		= "Вопрос & возврат";
$lang["daily read books"] 		= "ежедневные чтения книг";
$lang["requested books"] 		= "запрашиваемые книги";
$lang["report"] 				= "отчет";
$lang["fine report"] 			= "отчет казнь";
$lang["notification report"] 	= "отчет уведомления";

$lang["generate member ID"] 	= "генерировать идентификатор участника";
