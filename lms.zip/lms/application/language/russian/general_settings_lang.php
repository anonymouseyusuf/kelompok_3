<?php

// general settings
$lang["institute name"] = "Название института";
$lang["institute address"] = "институт Адрес";
$lang["institute email"] = "институт E-mail";
$lang["institute phone / mobile"] = "Институт Телефон / Мобильный";
$lang["logo"] = "логотип";
$lang["favicon"] = "Favicon";
$lang["language"] = "язык";
$lang["time zone"] = "Часовой пояс";
$lang["currency"] = "валюта";
$lang["terms and conditions"] = "условия и положения";
