<?php

$lang["type id"]   = "тип ID";
$lang["user type"] = "Тип пользователя";
$lang["address"]   = "адрес";
$lang["change password"]   = "изменить пароль";


