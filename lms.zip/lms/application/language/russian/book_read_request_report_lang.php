<?php
$lang["read - number of times"] = "прочитать - количество раз";
$lang["last read at"] = "последнего чтения в";
$lang["member name"] = "имя участника";
$lang["notification report"] = "отчет уведомления";
$lang["memberwise fine report"] = "Отчет состоит казнь";
$lang["reject request"]="отклонить запрос";
$lang["cause of rejection"]="причиной отказа";






