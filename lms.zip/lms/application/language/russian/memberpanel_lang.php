<?php
$lang["my circulation history"] = "моя история циркуляция";
$lang["my requested books"] = "мои запрашиваемые книги";
$lang["my notifications"] = "Мои уведомления";
$lang["request new book"] = "запросить новую книгу";
$lang["received at"] = "получил в";
$lang["is returned"] = "возвращается"; // for admin panel actually
