<?php
$lang["circulation"] 		 	= "циркуляция";
$lang["circulation settings"] 	= "настройки циркуляции";
$lang["issue and return"] 		= "Вопрос и возвращение";
$lang["issue & return"] 		= "Вопрос & возврат";
$lang["circulation list"] 		= "список циркуляция";
$lang['issue limit - days'] 	= 'Вопрос предел - дней';
$lang['issue limit - books'] 	= 'Вопрос предел - книги';
$lang['fine per day'] 			= 'нормально за день';
$lang['issue'] 					= 'вопрос';
$lang['new issue'] 				= 'новый выпуск';
$lang['return'] 				= 'вернуть';
$lang["fine"] 				    = "отлично";
$lang["penalty"] 				= "штраф";

$lang['issue from date'] = "Вопрос с даты";
$lang['issue date'] = "Дата выпуска";
$lang['expire from date'] = "истекает с момента";
$lang['issue to date'] = "Вопрос на сегодняшний день";
$lang['expire to date'] = "истекает в день";
$lang['expiry date'] = "срок годности";
$lang['return date'] = "Дата возврата";
$lang['return from date'] = "вернуться с даты";
$lang['return from to'] = "вернуться от до";

$lang["member search panel"]="Член панель поиска";
$lang["member ID/name"]="ID пользователя / имя";
$lang["book ID/name"]="Книга ID / имя";
$lang["current circulation"]="циркулирующий ток";

$lang['issued'] = "выпущен";
$lang['returned'] = "вернулся";
$lang['expired and returned'] = "Истекло и вернулся";
$lang['expired & returned'] = "истек и вернулся";
$lang['expired and not returned'] = "истек, и не возвращаются";
$lang['expired & not returned'] = "истек, и не возвращаются";



