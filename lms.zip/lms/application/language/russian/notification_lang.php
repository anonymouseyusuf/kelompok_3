<?php

$lang["SMS Gateway"] = "SMS Gateway";
$lang["Auth ID / Username"] = "Auth ID / Username";
$lang["Auth Token / Password"] = "Auth Token / Password";
$lang["Phone Number/ Mask"] = "Phone Number/ Mask";
$lang["API ID (Clickatell only)"] = "Api_id (только Clickatell)";

$lang['SMTP Host'] = "SMTP Host";
$lang['SMTP Port'] = "SMTP Port ";
$lang['SMTP User'] = "SMTP User";
$lang['SMTP Password'] = "SMTP Password";


$lang["send notification to delayed members"] = "отправить уведомление задержанных членов";
$lang["send notification"] = "отправить уведомление";
$lang["notification type"] = "тип уведомления";
$lang["sending, please wait..."] = "отправки, пожалуйста, подождите ...";


$lang["send sms/email notification"] = "Отправка SMS / электронной почты уведомления";


$lang["message subject"] 			= "Тема сообщения";
$lang["message"] 					= "сообщение";
$lang["notification"] 			    = "уведомление";
$lang["only notification"] 			= "только уведомление";
$lang["email and notification"] 	= "адрес электронной почты и уведомление";
$lang["SMS and notification"] 		= "SMS и уведомления";





