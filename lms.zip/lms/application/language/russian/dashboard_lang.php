<?php

// dashboard
$lang['total issued books + expired but not returned books'] =
"Всего, выпущенные книги + Истекло, но не возвращенные книги";

$lang['total issued'] = "общий выпущенный";
$lang['expired but not returned'] = "Истекло, но не вернулся";
$lang['overall report'] = "Сводный доклад";
$lang['total number of books'] = "Общее количество книг";
$lang['total number of issued books'] = "Общее количество выпущенных книг из";
$lang['total number of members'] = "Общее число членов";
$lang["today's report"] = "Сегодняшний доклад";
$lang["today's added books"] = "сегодня добавлены книги";
$lang["today's issued books"] = "сегодня выпущенные книги";
$lang["today's returned books"] = "сегодня вернулись книги";
$lang["today's added members"] = "сегодня добавлены члены";
$lang["this month's added book"] = "в этом месяце добавил книга";
$lang["current month's report"] = "Отчет текущего месяца";
$lang["this month's issued book"] = "в этом месяце вопрос Книга";
$lang["this month's returned book"] = "В этом месяце вернулся книга";

$lang["this month's added member"] = "в этом месяце добавил член"; 

$lang["issued and returned report for last 12 months"] = "выдается и возвращается отчет за последние 12 месяцев";
$lang["more information"] = "больше информации";

/*morris*/
$lang['number total returned'] = "Количество общий доход";
$lang['number total issued'] = "Количество общий выпущенный";


