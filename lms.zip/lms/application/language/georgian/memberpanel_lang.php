<?php
$lang["my circulation history"] = "ჩემი ცირკულაციის ისტორია";
$lang["my requested books"] = "ჩემი მოთხოვნილი წიგნები";
$lang["my notifications"] = "ჩემი შეტყობინებები";
$lang["request new book"] = "ახალი წიგნის მოთხოვნა";
$lang["received at"] = "მიღების დრო";
$lang["is returned"] = "დაბრუნებული"; // for admin panel actually
