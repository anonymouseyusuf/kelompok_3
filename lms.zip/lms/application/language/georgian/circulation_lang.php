<?php
$lang["circulation"] 		 	= "ცირკულაცია";
$lang["circulation settings"] 	= "ცირკულაციის პარამეტრები";
$lang["issue and return"] 		= "გაცემა და დაბრუნება";
$lang["issue & return"] 		= "გაცემა & დაბრუნება";
$lang["circulation list"] 		= "კალკულაციის სია";
$lang['issue limit - days'] 	= 'გაცემის ლიმიტი - დღეები';
$lang['issue limit - books'] 	= 'გაცემის ლიმიტი - წიგნები';
$lang['fine per day'] 			= 'ჯარიმა დღის მიხედვით';
$lang['issue'] 					= 'გაცემა';
$lang['new issue'] 				= 'ახალი გაცემა';
$lang['return'] 				= 'დაბრუნება';
$lang["fine"] 				    = "ჯარიმა";
$lang["penalty"] 				= "ჯარიმა";

$lang['issue from date'] = "გაცემა თარიღიდან";
$lang['issue date'] = "გაცემის თარიღი";
$lang['expire from date'] = "ვადაგადაცილებული თარიღიდან";
$lang['issue to date'] = "გაცემა თარიღზე";
$lang['expire to date'] = "ვადა ძალაშია თარიღამდე";
$lang['expiry date'] = "ვადის გასვლის თარიღი";
$lang['return date'] = "დაბრუნების თარიღი";
$lang['return from date'] = "დაბრუნება თარიღიდან";
$lang['return from to'] = "დაბრუნება თარიღზე";

$lang["member search panel"]="წევრის ძიების პანელი";
$lang["member ID/name"]="წევრის ID/სახელი";
$lang["book ID/name"]="წიგნის ID/სახელი";
$lang["current circulation"]="მიმდინარე ცირკულაცია";

$lang['issued'] = "გაცემული";
$lang['returned'] = "დაბრუნებული";
$lang['expired and returned'] = "ვადა გაუვიდა და დაბრუნებულია";
$lang['expired & returned'] = "ვადა გაუვიდა & დაბრუნებულია";
$lang['expired and not returned'] = "ვადა გაუვიდა და არ დაუბრუნებია";
$lang['expired & not returned'] = "ვადა გაუვიდა და არ დაუბრუნებია";



