<?php
$lang["read - number of times"] = "წაკითხვის რაოდენობა";
$lang["last read at"] = "უკანასკნელად წაკითხულია";
$lang["member name"] = "წევრის სახელი";
$lang["notification report"] = "შეტყობინებების რაპორტი";
$lang["memberwise fine report"] = "წევრის ჯარიმების რაპორტი";
$lang["reject request"]="გაუქმების მოთხოვნა";
$lang["cause of rejection"]="გაუქმების მიზეზი";






