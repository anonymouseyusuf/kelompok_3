<?php

$lang["type id"]   = "შეიყვანეთ ID";
$lang["user type"] = "მომხმარებლის ტიპი";
$lang["address"]   = "მისამართი";
$lang["change password"]   = "პაროლის შეცვლა";


