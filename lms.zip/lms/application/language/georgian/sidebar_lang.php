<?php

// admin sidebar
$lang["dashboard"] 				= "მართვის პანელი";
$lang["general settings"] 		= "მთავარი პარამეტრები";
$lang["books"] 					= "წიგნები";
$lang["book categories"] 		= "წიგნების კატეგორია";
$lang["member"] 		 		= "წევრი";
$lang["members"] 		 		= "წევრი";
$lang["member types"] 			= "წევრის ტიპი";
$lang['notification']			= 'შეტყობინება';
$lang['SMS settings']			= 'SMS პარამეტრები';
$lang['email SMTP settings']	= 'Email SMTP პარამეტრები';
$lang["notify delayed members"] = "დაგვიანებული წევრების შეტყობინება";
$lang["circulation"] 		 	= "ცირკულაცია";
$lang["circulation settings"] 	= "ცირკულაციის პარამეტრები";
$lang["issue & return"] 		= "მოთხოვნა & დაბრუნება";
$lang["daily read books"] 		= "დღიურად წაკითხული წიგნები";
$lang["requested books"] 		= "მოთხოვნილი წიგნები";
$lang["report"] 				= "რეპორტი";
$lang["fine report"] 			= "ჯარიმის რაპორტი";
$lang["notification report"] 	= "შეტყობინებების რაპორტი";

$lang["generate member ID"] 	= "წევრის ID-ის გერერირება";
