<?php 
$lang["home"]="მთავარი";
$lang["contact us"]="კონტაქტი";
$lang["register"]="რეგისტრაცია";
$lang["registration"]="რეგისტრაცია";
$lang["most recent books"]="პოპულარული მიმდინარე წიგნები";
$lang["most issued books"]="ყველაზე მოთხოვნადი წიგნები";
$lang["most read books"]="ყველაზე წაკითხვადი წიგნები";
$lang["it is read"]="სულ წაკითხული";
$lang["times"]="ჯერ";
$lang["search book"]="წიგნის ძიება";
$lang["search result"]="ძიების შედეგი";
$lang["pages"]="გვერდები";
$lang["send mail"]="წერილის გაგზავნა";
$lang["first name"]="სახელი";
$lang["last name"]="გვარი";
$lang["will be used as username"]="გამოყენებულ იქნება როგორც მომხმარებელი";
$lang["with country code"]="ქვეყნის კოდით";
$lang["by clicking register, you agree to the terms and conditions set out by this site"]=
"რეგისტრაციაზე დაჭერით თქვენ ეთანხმებით წესებსა და პირობებს";
$lang["added"]="დამატებული";
$lang["total books"]="სულ წიგნები";
$lang["available books"]="ხელმისაწვდომი წიგნები";
$lang["copy"]="კოპირება";
$lang["total issued"]="სულ მოთხოვნილი";
$lang["total read"]="სულ წაკითხული";
$lang["all category"]="ყველა კატეგორია";
$lang["send email"]="წერილის გაგზავნა";
$lang["i agree"]="ვეთანხმები";
?>