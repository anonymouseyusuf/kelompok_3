<?php

$lang['cal_su']			= "კვ";
$lang['cal_mo']			= "ორ";
$lang['cal_tu']			= "სა";
$lang['cal_we']			= "ოთ";
$lang['cal_th']			= "ხუ";
$lang['cal_fr']			= "პა";
$lang['cal_sa']			= "შა";
$lang['cal_sun']		= "კვი";
$lang['cal_mon']		= "ორშ";
$lang['cal_tue']		= "სამ";
$lang['cal_wed']		= "ოთხ";
$lang['cal_thu']		= "ხუთ";
$lang['cal_fri']		= "პარ";
$lang['cal_sat']		= "შაბ";
$lang['cal_sunday']		= "კვირა";
$lang['cal_monday']		= "ორშაბათი";
$lang['cal_tuesday']	= "სამშაბათი";
$lang['cal_wednesday']	= "ოთხშაბათი";
$lang['cal_thursday']	= "ხუთშაბათი";
$lang['cal_friday']		= "პარასკევი";
$lang['cal_saturday']	= "შაბათი";
$lang['cal_jan']		= "იან";
$lang['cal_feb']		= "თებ";
$lang['cal_mar']		= "მარ";
$lang['cal_apr']		= "აპრ";
$lang['cal_may']		= "მაი";
$lang['cal_jun']		= "ივნ";
$lang['cal_jul']		= "ივლ";
$lang['cal_aug']		= "აგვ";
$lang['cal_sep']		= "სექ";
$lang['cal_oct']		= "ოქტ";
$lang['cal_nov']		= "ნოე";
$lang['cal_dec']		= "დეკ";
$lang['cal_january']	= "იანვარი";
$lang['cal_february']	= "თებერვალი";
$lang['cal_march']		= "მარტი";
$lang['cal_april']		= "აპრილი";
$lang['cal_mayl']		= "მაისი";
$lang['cal_june']		= "ივნისი";
$lang['cal_july']		= "ივლისი";
$lang['cal_august']		= "აგვისტო";
$lang['cal_september']	= "სექტემბერი";
$lang['cal_october']	= "ოქტომბერი";
$lang['cal_november']	= "ნოემბერი";
$lang['cal_december']	= "დეკემბერი";


/* End of file calendar_lang.php */
/* Location: ./system/language/english/calendar_lang.php */