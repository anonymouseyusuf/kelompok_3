<?php

$lang["SMS Gateway"] = "SMS Gateway";
$lang["Auth ID / Username"] = "Auth ID / მომხმარებელი";
$lang["Auth Token / Password"] = "Auth Token / პაროლი";
$lang["Phone Number/ Mask"] = "ტელეფონის ნომერი/ Mask";
$lang["API ID (Clickatell only)"] = "API ID (Clickatell მხოლოდ)";

$lang['SMTP Host'] = "SMTP ჰოსტი";
$lang['SMTP Port'] = "SMTP პორტი";
$lang['SMTP User'] = "SMTP მომხმარებელი";
$lang['SMTP Password'] = "SMTP პაროლი";


$lang["send notification to delayed members"] = "გაუგზავნე წევრებს შეტყობინება დაგვიანებულ წიგნებზე.";
$lang["send notification"] = "შეტყობინების გაგზავნა.";
$lang["notification type"] = "შეტყობინების ტიპი.";
$lang["sending, please wait..."] = "იგზავნება, გთხოვთ დაელოდოთ...";
$lang["send sms/email notification"] = "გაგზავნე SMS/Email შეტყობინება";

// added
$lang["message subject"] 			= "წერილის თემა";
$lang["message"] 					= "წერილი";
$lang["notification"] 			    = "შეტყობინება";
$lang["only notification"] 			= "მხოლოდ შეტყობინება";
$lang["email and notification"] 	= "Email და შეტყობინება";
$lang["SMS and notification"] 		= "SMS და შეტყობინება";




