<?php

// general settings
$lang["institute name"] = "უნივერსიტეტის სახელი";
$lang["institute address"] = "უნივერსიტეტის მისამართი";
$lang["institute email"] = "უნივერსიტეტის Email";
$lang["institute phone / mobile"] = "უნივერსიტეტის ტელეფონი / მობილური";
$lang["logo"] = "ლოგო";
$lang["favicon"] = "ფავიკონი";
$lang["language"] = "ენა";
$lang["time zone"] = "დროის სარტყელი";
$lang["currency"] = "კურსი";
$lang["terms and conditions"] = "წესები და პირობები";
