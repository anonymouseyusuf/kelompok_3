<?php

// admin sidebar
$lang["dashboard"] 				= "لوحة أجهزة القياس";
$lang["general settings"] 		= "الإعدادات العامة";
$lang["books"] 					= "الكتب";
$lang["book categories"] 		= "فئات الكتاب";
$lang["member"]  				= "عضو";
$lang["members"] 		 		= "أعضاء";
$lang["member types"] 			= "أنواع الأعضاء";
$lang['notification']			= 'إعلام';
$lang['SMS settings']			= 'ضبط SMS';
$lang['email SMTP settings']	= 'إعدادات البريد الإلكتروني SMTP';
$lang["notify delayed members"]= "بإخطار أعضاء المتأخر";
$lang["circulation"] 		 	= "تداول";
$lang["circulation settings"] 	= "ضبط التداول";
$lang["issue & return"] 		= "تعيين وعودة";
$lang["daily read books"] 		= "الكتب المقروءة اليومية";
$lang["requested books"] 		= "الكتب المطلوبة";
$lang["report"] 				= "تقرير";
$lang["fine report"] 			= "تقرير غرامة";
$lang["notification report"] 	= "تقرير إعلام";

$lang["generate member ID"] 	= "توليد معرف العضو";
