<?php
$lang["my circulation history"] = "بلدي التداول التاريخ";
$lang["my requested books"] = "كتبي طلب";
$lang["my notifications"] = "إخطارات بلدي";
$lang["request new book"] = "طلب كتاب جديد";
$lang["received at"] = "تلقى في";
$lang["is returned"] = "يتم إرجاع"; // for admin panel actually
