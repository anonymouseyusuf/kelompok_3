<?php
$lang["read - number of times"] = "قراءة - عدد المرات";
$lang["last read at"] = "قراءة مشاركة في";
$lang["member name"] = "اسم عضو";
$lang["notification report"] = "تقرير إعلام";
$lang["memberwise fine report"] = "تقرير عقوبة الأعضاء";
$lang["reject request"]="رفض طلب";
$lang["cause of rejection"]="سبب الرفض";






