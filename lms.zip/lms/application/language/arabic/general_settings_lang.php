<?php

// general settings
$lang["institute name"] = "اسم المعهد";
$lang["institute address"] = "معهد عنوان";
$lang["institute email"] = "معهد البريد الإلكتروني";
$lang["institute phone / mobile"] = "معهد الهاتف / الجوال";
$lang["logo"] = "شعار";
$lang["favicon"] = "فافيكون";
$lang["language"] = "لغة";
$lang["time zone"] = "منطقة زمنية";
$lang["currency"] = "عملة";
$lang["terms and conditions"] = "الأحكام والشروط";
