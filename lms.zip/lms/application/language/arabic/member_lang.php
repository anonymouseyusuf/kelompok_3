<?php

$lang["type id"]   = "نوع معرف";
$lang["user type"] = "نوع المستخدم";
$lang["address"]   = "العنوان";
$lang["change password"]   = "تغيير كلمة المرور";


