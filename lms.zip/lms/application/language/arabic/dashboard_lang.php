<?php

// dashboard
$lang['total issued books + expired but not returned books'] = "مجموع الكتب إسناد + الكتب منتهية الصلاحية ولكن لم يعودوا";
$lang['total issued'] = "مجموعه تعيين";
$lang['expired but not returned'] = "انتهت ولكن لم يعودوا";
$lang['overall report'] = "تقرير شامل";
$lang['total number of books'] = "إجمالي عدد الكتب";
$lang['total number of issued books'] = "إجمالي عدد الكتب الصادرة";
$lang['total number of members'] = "إجمالي عدد الأعضاء";
$lang["today's report"] = "تقرير اليوم";
$lang["today's added books"] = "كتب اليوم المضافة";
$lang["today's issued books"] = "الكتب المسندة اليوم";
$lang["today's returned books"] = "كتب اليوم عاد";
$lang["today's added members"] = "وأضاف أعضاء اليوم";
$lang["this month's added book"] = "وأضاف الكتاب هذا الشهر";
$lang["current month's report"] = "تقرير الشهر الحالي";
$lang["this month's issued book"] = "تعيين كتاب هذا الشهر";
$lang["this month's returned book"] = "عاد كتاب هذا الشهر";

$lang["this month's added member"] = "عضو أضاف هذا الشهر"; 

$lang["issued and returned report for last 12 months"] = "أصدرت وعاد التقرير لمدة اثني عشر شهرا الماضية";
$lang["more information"] = "المزيد من المعلومات";


/*morris*/
$lang['number total returned'] = "Total Returned";
$lang['number total issued'] = "Total Issued";



