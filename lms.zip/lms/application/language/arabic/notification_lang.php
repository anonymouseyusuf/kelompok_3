<?php

$lang["SMS Gateway"] = "SMS Gateway";
$lang["Auth ID / Username"] = "Auth ID / Username";
$lang["Auth Token / Password"] = "Auth Token / Password";
$lang["Phone Number/ Mask"] = "Phone Number/ Mask";
$lang["API ID (Clickatell only)"] = "API_ID (Clickatell فقط)";

$lang['SMTP Host'] = "SMTP Host";
$lang['SMTP Port'] = "SMTP Port ";
$lang['SMTP User'] = "SMTP User";
$lang['SMTP Password'] = "SMTP Password";


$lang["send notification to delayed members"] = "إرسال إشعار إلى أعضاء تأخير";
$lang["send notification"] = "إرسال إشعار";
$lang["notification type"] = "نوع إعلام";
$lang["sending, please wait..."] = "إرسال، يرجى الانتظار ...";


$lang["send sms/email notification"] = "ارسال الرسائل القصيرة إشعار / البريد الإلكتروني";


$lang["message subject"] 			= "عنوان الرسالة";
$lang["message"] 					= "الرسالة";
$lang["notification"] 			    = "إعلام";
$lang["only notification"] 			= "إعلام فقط";
$lang["email and notification"] 	= "البريد الإلكتروني وإعلام";
$lang["SMS and notification"] 		= "SMS والإخطار";




