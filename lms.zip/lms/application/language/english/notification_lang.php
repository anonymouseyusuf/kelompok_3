<?php

$lang["SMS Gateway"] = "SMS Gateway";
$lang["Auth ID / Username"] = "Auth ID / Username";
$lang["Auth Token / Password"] = "Auth Token / Password";
$lang["Phone Number/ Mask"] = "Phone Number/ Mask";
$lang["API ID (Clickatell only)"] = "API ID (Clickatell only)";

$lang['SMTP Host'] = "SMTP Host";
$lang['SMTP Port'] = "SMTP Port";
$lang['SMTP User'] = "SMTP User";
$lang['SMTP Password'] = "SMTP Password";


$lang["send notification to delayed members"] = "Send notification to delayed members.";
$lang["send notification"] = "Send notification.";
$lang["notification type"] = "Notification type.";
$lang["sending, please wait..."] = "Sending, Please wait...";
$lang["send sms/email notification"] = "Send SMS/Email Notification";

// added
$lang["message subject"] 			= "Message Subject";
$lang["message"] 					= "Message";
$lang["notification"] 			    = "Notification";
$lang["only notification"] 			= "Only Notification";
$lang["email and notification"] 	= "Email and Notification";
$lang["SMS and notification"] 		= "SMS and Notification";




