<?php

$lang["type id"]   = "Type ID";
$lang["user type"] = "User Type";
$lang["address"]   = "Address";
$lang["change password"]   = "Change Password";


