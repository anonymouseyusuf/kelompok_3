<?php

// admin sidebar
$lang["dashboard"] 				= "Dashboard";
$lang["general settings"] 		= "General Settings";
$lang["books"] 					= "Books";
$lang["book categories"] 		= "Book Category";
$lang["member"] 		 		= "Member";
$lang["members"] 		 		= "Member";
$lang["member types"] 			= "Member Type";
$lang['notification']			= 'Notification';
$lang['SMS settings']			= 'SMS Settings';
$lang['email SMTP settings']	= 'Email SMTP Settings';
$lang["notify delayed members"] = "Notify Delayed Members";
$lang["circulation"] 		 	= "Circulation";
$lang["circulation settings"] 	= "Circulation Settings";
$lang["issue & return"] 		= "Issue & Return";
$lang["daily read books"] 		= "Daily Read Books";
$lang["requested books"] 		= "Requested Books";
$lang["report"] 				= "Report";
$lang["fine report"] 			= "Fine/Penalty Report";
$lang["notification report"] 	= "Notification Report";

$lang["generate member ID"] 	= "Generate Member ID";
