<?php

$lang['terabyte_abbr'] = "Terabytes";
$lang['gigabyte_abbr'] = "Gigabytes";
$lang['megabyte_abbr'] = "Megabytes";
$lang['kilobyte_abbr'] = "Kilobytes";
$lang['bytes'] = "Bytes";

/* End of file number_lang.php */
/* Location: ./system/language/english/number_lang.php */