<?php
$lang["read - number of times"] = "Read - Number of Times";
$lang["last read at"] = "Last Read At";
$lang["member name"] = "Member Name";
$lang["notification report"] = "Notification Report";
$lang["memberwise fine report"] = "Memberwise Fine Report";
$lang["reject request"]="Reject Request";
$lang["cause of rejection"]="Cause of Rejection";






