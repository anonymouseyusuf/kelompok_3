<?php
$lang['your data has been successfully stored into the database.'] = "Your data has been successfully stored into the database.";
$lang['something went wrong, please try again.'] = "Something went wrong, please try again.";
$lang['your data has been failed to stored into the database.'] = "Your data has been failed to stored into the database.";
$lang['your data has been successfully deleted from the database.'] = "Your data has been successfully deleted from the database.";
$lang['your data has been failed to delete from the database.'] = "Your data has been failed to delete from the database.";
$lang['sorry! your data does not exist'] = "Sorry! your data does not exist";
$lang["this book isn't available right now"] = "This book isn't available right now";
$lang["the data you had insert may not be saved.\\nare you sure you want to go back to list?"]="The data you had insert may not be saved.\\nare you sure you want to go back to list?";
$lang["the data you had change may not be saved.\\nare you sure you want to go back to list?"]="The data you had change may not be saved.\\nare you sure you want to go back to list?";
$lang["are you sure that you want to delete this record?"]="Are you sure that you want to delete this record?";
$lang["you haven't select any book"]="You haven't select any book.";
$lang["invalid email or password"]="Invalid email or password.";
$lang["your registration is successfull but one more step to go. you will be notified through email when admin approves you."]="Your registration is successfull but one more step to go. You will be notified through email when admin approves you.";
$lang["please enter an email address"]="Please enter an email address.";
$lang["this email is not associated with any member"]="This email is not associated with any member.";
$lang["please enter the code"]="Please enter the code.";
$lang["passwords don't match"]="Passwords don't match.";
$lang["password recovery code does not match"]="Password recovery code does not match.";
$lang["password recovery code is expired"]="Password recovery code is expired.";
$lang["password is updated successfully"]="Password is updated successfully.";
$lang["you did not select any member"]="You did not select any member.";
$lang["something is missing"]="Something is missing.";
// add
$lang['sorry! there is no such book'] = "Sorry! there is no such book.";
$lang['sorry! there is no such member'] = "Sorry! there is no such member.";
$lang['sorry ! this book is not available right now'] = "Sorry ! this book is not available right now.";
$lang['sorry! this user can not be issued another book'] = "Sorry! this user can not be issued another book.";
$lang['are you sure'] = "are you sure?";
$lang["your registration is successfull but one more step to go. you will be notified through email when admin approves you"]=
"Your registration is successfull but one more step to go. You will be notified through email when admin approves you.";
$lang["no data found"]="No data found.";
$lang["no book matches with your search query"]="No book matches with your search query.";
$lang["please use the search form or category links to search books"]=
"Please use the search form or category links to search books.";
$lang["we have received your email. we will contact you through email as soon as possible"]=
"We have received your email. We will contact you through email as soon as possible.";
