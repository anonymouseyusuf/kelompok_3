<?php 
$lang["home"]="Home";
$lang["contact us"]="Contact Us";
$lang["register"]="Register";
$lang["registration"]="Registration";
$lang["most recent books"]="Most Recent Books";
$lang["most issued books"]="Most Issued Books";
$lang["most read books"]="Most Read Books";
$lang["it is read"]="Total Read";
$lang["times"]="times";
$lang["search book"]="Search Book";
$lang["search result"]="Search Result";
$lang["pages"]="Pages";
$lang["send mail"]="Send Mail";
$lang["first name"]="First Name";
$lang["last name"]="Last Name";
$lang["will be used as username"]="Will be Used as Username";
$lang["with country code"]="With Country Code";
$lang["by clicking register, you agree to the terms and conditions set out by this site"]=
"By clicking register, you agree to the terms and conditions set out by this site";
$lang["added"]="Added";
$lang["total books"]="Total Books";
$lang["available books"]="Available Books";
$lang["copy"]="Copy";
$lang["total issued"]="Total Issued";
$lang["total read"]="Total Read";
$lang["all category"]="All Category";
$lang["send email"]="Send Email";
$lang["i agree"]="I Agree";
?>