<?php
$lang["my circulation history"] = "My Circulation History";
$lang["my requested books"] = "My Requested Books";
$lang["my notifications"] = "My Notifications";
$lang["request new book"] = "Request New Book";
$lang["received at"] = "Received at";
$lang["is returned"] = "Is Returned"; // for admin panel actually
