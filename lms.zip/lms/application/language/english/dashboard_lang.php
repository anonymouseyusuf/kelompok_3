<?php

// dashboard
$lang['total issued books + expired but not returned books'] = "Total Issued Books + Expired But Not Returned Books";
$lang['total issued'] = "Total Issued";
$lang['expired but not returned'] = "Expired But Not Returned";
$lang['overall report'] = "Overall Report";
$lang['total number of books'] = "Total Number of Books";
$lang['total number of issued books'] = "Total Number of Issued Books";
$lang['total number of members'] = "Total Number of Members";
$lang["today's report"] = "Today's Report";
$lang["today's added books"] = "Today's Added Books";
$lang["today's issued books"] = "Today's Issued Books";
$lang["today's returned books"] = "Today's Returned Books";
$lang["today's added members"] = "Today's Added Members";
$lang["current month's report"] = "Current Month's Report";
$lang["this month's added book"] = "This month's Added Book";
$lang["this month's issued book"] = "This Month's Issued Book";
$lang["this month's returned book"] = "This Month's Returned Book";
$lang["this month's added member"] = "This Month's Added Member"; 

$lang["issued and returned report for last 12 months"] = "Issued and Returned Report for Last 12 Months";
$lang["more information"] = "More Information";

/*morris*/
$lang['number total returned'] = "Total Returned";
$lang['number total issued'] = "Total Issued";

