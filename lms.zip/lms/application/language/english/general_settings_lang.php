<?php

// general settings
$lang["institute name"] = "Institute Name";
$lang["institute address"] = "Institute Address";
$lang["institute email"] = "Institute Email";
$lang["institute phone / mobile"] = "Institute Phone / Mobile";
$lang["logo"] = "Logo";
$lang["favicon"] = "Favicon";
$lang["language"] = "Language";
$lang["time zone"] = "Time Zone";
$lang["currency"] = "Currency";
$lang["terms and conditions"] = "Terms and Conditions";
