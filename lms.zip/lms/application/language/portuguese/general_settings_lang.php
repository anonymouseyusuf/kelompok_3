<?php

// general settings
$lang["institute name"] = "Nome do Instituto";
$lang["institute address"] = "Instituto Endereço";
$lang["institute email"] = "Instituto Email";
$lang["institute phone / mobile"] = "Instituto Telefone / Telemóvel";
$lang["logo"] = "Logotipo";
$lang["favicon"] = "faviconfavicon";
$lang["language"] = "idioma";
$lang["time zone"] = "Fuso horário";
$lang["currency"] = "Moeda";
$lang["terms and conditions"] = "termos e Condições";
