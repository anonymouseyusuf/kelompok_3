<?php
$lang["my circulation history"] = "minha história circulação";
$lang["my requested books"] = "meus livros solicitados";
$lang["my notifications"] = "minhas notificações";
$lang["request new book"] = "solicitar novo livro";
$lang["received at"] = "recebida no";
$lang["is returned"] = "é devolvido"; // for admin panel actually
