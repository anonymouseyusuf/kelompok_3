<?php
$lang["read - number of times"] = "leia - número de vezes";
$lang["last read at"] = "última leitura no";
$lang["member name"] = "nome de membro";
$lang["notification report"] = "relatório de notificação";
$lang["memberwise fine report"] = "relatório penalidade membro";
$lang["reject request"]="rejeitar o pedido";
$lang["cause of rejection"]="causa de rejeição";






