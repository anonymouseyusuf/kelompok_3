<?php

// dashboard
$lang['total issued books + expired but not returned books'] = 
"Total de livros emitidos + Livros expirados mas não retornaram";

$lang['total issued'] = "total emitido";
$lang['expired but not returned'] = "expirado, mas não retornou";
$lang['overall report'] = "relatório global";
$lang['total number of books'] = "número total de livros";
$lang['total number of issued books'] = "número total de livros emitidos";
$lang['total number of members'] = "número total de membros";
$lang["today's report"] = "o relatório de hoje";
$lang["today's added books"] = "livros de hoje adicionadas";
$lang["today's issued books"] = "livros de emissão de hoje";
$lang["today's returned books"] = "livros retornados de hoje";
$lang["today's added members"] = "membros atuais adicionadas";
$lang["this month's added book"] = "livro adicionado este mês";
$lang["current month's report"] = "O relatório do mês atual";
$lang["this month's issued book"] = "emissão livro deste mês";
$lang["this month's returned book"] = "livro retornou este mês";

$lang["this month's added member"] = "membro adicionado este mês"; 

$lang["issued and returned report for last 12 months"] = "relatório emitido e retornado para últimos 12 meses";
$lang["more information"] = "mais informação";


/*morris*/
$lang['number total returned'] = "número retorno total";
$lang['number total issued'] = "número total emitido";

