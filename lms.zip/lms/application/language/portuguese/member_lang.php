<?php

$lang["type id"]   = "tipo de id";
$lang["user type"] = "tipo de usuário";
$lang["address"]   = "endereço";
$lang["change password"]   = "alterar a senha";


