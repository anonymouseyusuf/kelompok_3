<?php

$lang["SMS Gateway"] = "SMS Gateway";
$lang["Auth ID / Username"] = "Auth ID / Username";
$lang["Auth Token / Password"] = "Auth Token / Password";
$lang["Phone Number/ Mask"] = "Phone Number/ Mask";
$lang["API ID (Clickatell only)"] = "API_ID (apenas Clickatell)";

$lang['SMTP Host'] = "SMTP Host";
$lang['SMTP Port'] = "SMTP Port ";
$lang['SMTP User'] = "SMTP User";
$lang['SMTP Password'] = "SMTP Password";


$lang["send notification to delayed members"] = "enviar uma notificação aos membros atrasadas";
$lang["send notification"] = "enviar notificação";
$lang["notification type"] = "tipo de notificação";
$lang["sending, please wait..."] = "envio, por favor aguarde ...";


$lang["send sms/email notification"] = "enviar sms notificação / e-mail";


$lang["message subject"] 			= "Assunto da mensagem";
$lang["message"] 					= "mensagem";
$lang["notification"] 			    = "notificação";
$lang["only notification"] 			= "apenas notificações";
$lang["email and notification"] 	= "e-mail e notificação";
$lang["SMS and notification"] 		= "SMS e notificação";





