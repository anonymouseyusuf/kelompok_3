<?php

// admin sidebar
$lang["dashboard"] 				= "painel de instrumentos";
$lang["general settings"] 		= "Configurações Gerais";
$lang["books"] 					= "livros";
$lang["book categories"] 		= "Categorias livro";
$lang["member"]  				= "membro";
$lang["members"] 		 		= "membros";
$lang["member types"] 			= "tipos de membro";
$lang['notification']			= "notificação";
$lang['SMS settings']			= "definições de SMS";
$lang['email SMTP settings']	= "configurações de e-mail SMTP";
$lang["notify delayed members"]= "notificar os membros em atraso";
$lang["circulation"] 		 	= "circulação";
$lang["circulation settings"] 	= "configurações de circulação";
$lang["issue & return"] 		= "emissão e retorno";
$lang["daily read books"] 		= "livros de leitura diária";
$lang["requested books"] 		= "livros solicitados";
$lang["report"] 				= "relatório";
$lang["fine report"] 			= "relatório penalidade";
$lang["notification report"] 	= "relatório de notificação";

$lang["generate member ID"] 	= "gerar identificação de membro";
