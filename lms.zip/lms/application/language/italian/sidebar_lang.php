<?php

// admin sidebar
$lang["dashboard"] 				= "cruscotto";
$lang["general settings"] 		= "impostazioni generali";
$lang["books"] 					= "libri";
$lang["book categories"] 		= "categorie di libri";
$lang["member"]  				= "membro";
$lang["members"] 		 		= "membri";
$lang["member types"] 			= "tipi di membri";
$lang['notification']			= "notifica";
$lang['SMS settings']			= "impostazioni SMS";
$lang['email SMTP settings']	= "Impostazioni e-mail SMTP";
$lang["notify delayed members"]= "informare i membri in ritardo";
$lang["circulation"] 		 	= "circolazione";
$lang["circulation settings"] 	= "impostazioni di circolazione";
$lang["issue & return"] 		= "problema e ritorno";
$lang["daily read books"] 		= "libri letti ogni giorno";
$lang["requested books"] 		= "libri richiesti";
$lang["report"] 				= "relazione";
$lang["fine report"] 			= "rapporto di rigore";
$lang["notification report"] 	= "rapporto di notifica";

$lang["generate member ID"] 	= "generare ID membro";
