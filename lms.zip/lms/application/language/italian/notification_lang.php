<?php

$lang["SMS Gateway"] = "SMS Gateway";
$lang["Auth ID / Username"] = "Auth ID / Username";
$lang["Auth Token / Password"] = "Auth Token / Password";
$lang["Phone Number/ Mask"] = "Phone Number/ Mask";
$lang["API ID (Clickatell only)"] = "API_ID (solo Clickatell)";

$lang['SMTP Host'] = "SMTP Host";
$lang['SMTP Port'] = "SMTP Port ";
$lang['SMTP User'] = "SMTP User";
$lang['SMTP Password'] = "SMTP Password";


$lang["send notification to delayed members"] = "inviare una notifica ai membri in ritardo";
$lang["send notification"] = "inviare la notifica";
$lang["notification type"] = "tipo di notifica";
$lang["sending, please wait..."] = "Invio in corso ...";


$lang["send sms/email notification"] = "inviare sms / email di notifica";


$lang["message subject"] 			= "soggetto del messaggio";
$lang["message"] 					= "messaggio";
$lang["notification"] 			    = "notifica";
$lang["only notification"] 			= "solo la comunicazione";
$lang["email and notification"] 	= "e-mail e la notifica";
$lang["SMS and notification"] 		= "SMS e notifica";





