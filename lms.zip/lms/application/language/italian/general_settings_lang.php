<?php

// general settings
$lang["institute name"] = "Nome Istituto";
$lang["institute address"] = "Institute Indirizzo";
$lang["institute email"] = "Istituto Email";
$lang["institute phone / mobile"] = "Istituto Telefono / Cellulare";
$lang["logo"] = "Logo";
$lang["favicon"] = "favicon";
$lang["language"] = "lingua";
$lang["time zone"] = "Fuso orario";
$lang["currency"] = "Valuta";
$lang["terms and conditions"] = "termini e condizioni";
