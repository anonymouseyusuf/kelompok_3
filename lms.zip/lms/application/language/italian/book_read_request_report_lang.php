<?php
$lang["read - number of times"] = "leggere - numero di volte";
$lang["last read at"] = "ultima lettura a";
$lang["member name"] = "nome del membro";
$lang["notification report"] = "rapporto di notifica";
$lang["memberwise fine report"] = "rapporto pena membro";
$lang["reject request"]="respingere la richiesta";
$lang["cause of rejection"]="causa del rifiuto";






