<?php
$lang["my circulation history"] = "la mia storia circolazione";
$lang["my requested books"] = "i miei libri richiesti";
$lang["my notifications"] = "le notifiche";
$lang["request new book"] = "richiedere nuovo libro";
$lang["received at"] = "pervenuta in";
$lang["is returned"] = "viene restituito"; // for admin panel actually
