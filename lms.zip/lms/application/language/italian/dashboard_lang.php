<?php

// dashboard
$lang['total issued books + expired but not returned books'] = 
"Totale libri emesse + libri scaduti ma non restituiti";

$lang['total issued'] = "totale emesso";
$lang['expired but not returned'] = "scaduto ma non restituiti";
$lang['overall report'] = "relazione globale";
$lang['total number of books'] = "numero totale di libri";
$lang['total number of issued books'] = "numero totale di libri rilasciati";
$lang['total number of members'] = "numero totale dei membri";
$lang["today's report"] = "la relazione di oggi";
$lang["today's added books"] = "Libri aggiunti di oggi";
$lang["today's issued books"] = "libri rilasciati oggi";
$lang["today's returned books"] = "i libri restituiti di oggi";
$lang["today's added members"] = "i membri aggiunti di oggi";
$lang["this month's added book"] = "libro aggiunto di questo mese";
$lang["current month's report"] = "relazione del mese corrente";
$lang["this month's issued book"] = "il libro numero di questo mese";
$lang["this month's returned book"] = "libro tornati di questo mese";

$lang["this month's added member"] = "membro aggiunto di questo mese"; 

$lang["issued and returned report for last 12 months"] = "rilasciato ed è tornato relazione ultimi 12 mesi";
$lang["more information"] = "maggiori informazioni";

/*morris*/
$lang['number total returned'] = "numero di rientro totale";
$lang['number total issued'] = "numero totale emesso";


