<?php

$lang["type id"]   = "tipo id";
$lang["user type"] = "tipo di utente";
$lang["address"]   = "indirizzo";
$lang["change password"]   = "cambiare la password";


