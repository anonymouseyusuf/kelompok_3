<?php
$lang["circulation"] 		 	= "circolazione";
$lang["circulation settings"] 	= "impostazioni di circolazione";
$lang["issue and return"] 		= "assegnare e ritorno";
$lang["issue & return"] 		= "assegnare e ritorno";
$lang["circulation list"] 		= "lista circolazione";
$lang['issue limit - days'] 	= 'assegnare limite - giorni';
$lang['issue limit - books'] 	= 'assegnare limite - libri';
$lang['fine per day'] 			= 'multa al giorno';
$lang['issue'] 					= 'assegnare';
$lang['new issue'] 				= 'nuova assegnare';
$lang['return'] 				= 'ritorno';
$lang["fine"] 				    = "punizione";
$lang["penalty"] 				= "punizione";

$lang['issue from date'] = "assegnare dalla data di";
$lang['issue date'] = "data di assegnare";
$lang['expire from date'] = "a partire dalla data di scadenza";
$lang['issue to date'] = "assegnare ad oggi";
$lang['expire to date'] = "scadono ad oggi";
$lang['expiry date'] = "data di scadenza";
$lang['return date'] = "data di ritorno";
$lang['return from date'] = "tornare dalla data di";
$lang['return from to'] = "tornare da a";

$lang["member search panel"]="pannello di ricerca membro";
$lang["member ID/name"]="ID membro / nome";
$lang["book ID/name"]="libro ID / nome";
$lang["current circulation"]="circolazione di corrente";

$lang['issued'] = "addetto";
$lang['returned'] = "tornato";
$lang['expired and returned'] = "scaduti e restituiti";
$lang['expired & returned'] = "scaduti e siamo tornati";
$lang['expired and not returned'] = "scaduto e non restituiti";
$lang['expired & not returned'] = "scaduto o non restituiti";



