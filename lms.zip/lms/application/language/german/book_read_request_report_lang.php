<?php
$lang["read - number of times"] = "Lesen Sie - mehrmals";
$lang["last read at"] = "zuletzt gelesenen an";
$lang["member name"] = "Mitgliedsname";
$lang["notification report"] = "Benachrichtigungsbericht";
$lang["memberwise fine report"] = "Mitglied Strafe Bericht";
$lang["reject request"]="Antrag ablehnen";
$lang["cause of rejection"]="Ursache für die Ablehnung";






