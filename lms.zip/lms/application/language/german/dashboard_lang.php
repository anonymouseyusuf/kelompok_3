<?php

// dashboard
$lang['total issued books + expired but not returned books'] = 
"gesamten ausgegebenen Bücher + abgelaufenen, aber nicht zurück Bücher";

$lang['total issued'] = "gesamten ausgegebenen";
$lang['expired but not returned'] = "abgelaufenen, aber nicht zurück";
$lang['overall report'] = "Gesamtbericht";
$lang['total number of books'] = "Gesamtzahl der Bücher";
$lang['total number of issued books'] = "Gesamtzahl der ausgegebenen Bücher";
$lang['total number of members'] = "Gesamtzahl der Mitglieder";
$lang["today's report"] = "Der heutige Bericht";
$lang["today's added books"] = "heutigen hinzugefügt Bücher";
$lang["today's issued books"] = "heutigen ausgestellt Bücher";
$lang["today's returned books"] = "heutigen zurückgegeben Bücher";
$lang["today's added members"] = "heutigen hinzugefügt Mitglieder";
$lang["this month's added book"] = "diesen Monat hinzugefügt Buch";
$lang["current month's report"] = "Bericht aktuellen Monats";
$lang["this month's issued book"] = "dieses Monats Thema Buch";
$lang["this month's returned book"] = "dieses Monats zurück Buch";

$lang["this month's added member"] = "diesen Monat hinzugefügt Mitglied"; 

$lang["issued and returned report for last 12 months"] = "ausgegeben und zurückBericht für letzten 12 Monaten";
$lang["more information"] = "mehr Informationen";

/*morris*/
$lang['number total returned'] = "Anzahl Total Return";
$lang['number total issued'] = "Anzahl gesamten ausgegebenen";




