<?php

// admin sidebar
$lang["dashboard"] 				= "Armaturenbrett";
$lang["general settings"] 		= "Allgemeine Einstellungen";
$lang["books"] 					= "Bücher";
$lang["book categories"] 		= "Buch Kategorien";
$lang["member"]  				= "Mitglied";
$lang["members"] 		 		= "Mitglieder";
$lang["member types"] 			= "Mitglied Typen";
$lang['notification']			= "Mitteilung";
$lang['SMS settings']			= "SMS-Einstellungen";
$lang['email SMTP settings']	= "E-Mail-SMTP-Einstellungen";
$lang["notify delayed members"]= "benachrichtigen verzögerte Mitglieder";
$lang["circulation"] 		 	= "Verkehr";
$lang["circulation settings"] 	= "Umlauf-Einstellungen";
$lang["issue & return"] 		= "Frage & Rückkehr";
$lang["daily read books"] 		= "Tagesgelesenen Bücher";
$lang["requested books"] 		= "angeforderten Bücher";
$lang["report"] 				= "Bericht";
$lang["fine report"] 			= "Strafe Bericht";
$lang["notification report"] 	= "Benachrichtigungsbericht";

$lang["generate member ID"] 	= "erzeugen Mitglieds-ID";
