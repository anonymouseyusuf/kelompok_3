<?php

$lang["type id"]   = "Typ-ID";
$lang["user type"] = "Benutzertyp";
$lang["address"]   = "Adresse";
$lang["change password"]   = "Kennwort ändern";


