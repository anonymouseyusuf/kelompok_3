<?php
$lang["my circulation history"] = "meine Zirkulation Geschichte";
$lang["my requested books"] = "meine Wunsch-Bücher";
$lang["my notifications"] = "meine Benachrichtigungen";
$lang["request new book"] = "fordern neues Buch";
$lang["received at"] = "zumin erhalten";
$lang["is returned"] = "wird zurückgegeben"; // for admin panel actually
