<?php

$lang["SMS Gateway"] = "SMS Gateway";
$lang["Auth ID / Username"] = "Auth ID / Username";
$lang["Auth Token / Password"] = "Auth Token / Password";
$lang["Phone Number/ Mask"] = "Phone Number/ Mask";
$lang["API ID (Clickatell only)"] = "API_ID (Clickatell nur)";

$lang['SMTP Host'] = "SMTP Host";
$lang['SMTP Port'] = "SMTP Port ";
$lang['SMTP User'] = "SMTP User";
$lang['SMTP Password'] = "SMTP Password";


$lang["send notification to delayed members"] = "Benachrichtigung senden, um verzögerte Mitglieder";
$lang["send notification"] = "Benachrichtigung senden";
$lang["notification type"] = "Benachrichtigungstyp";
$lang["sending, please wait..."] = "Senden, bitte warten ...";


$lang["send sms/email notification"] = "senden Sie SMS / Email Benachrichtigung";


$lang["message subject"] 			= "Betreff der Nachricht";
$lang["message"] 					= "Nachricht";
$lang["notification"] 			    = "Mitteilung";
$lang["only notification"] 			= "nur Meldung";
$lang["email and notification"] 	= "E-Mail und Benachrichtigung";
$lang["SMS and notification"] 		= "SMS-Benachrichtigung";





