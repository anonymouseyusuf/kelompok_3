<?php

// general settings
$lang["institute name"] = "Name des Institutes";
$lang["institute address"] = "Institut Adresse";
$lang["institute email"] = "Instituts per E-Mail";
$lang["institute phone / mobile"] = "Institut Telefon / Handy";
$lang["logo"] = "Logo";
$lang["favicon"] = "favicon";
$lang["language"] = "Sprache";
$lang["time zone"] = "Zeitzone";
$lang["currency"] = "Währung";
$lang["terms and conditions"] = "Geschäftsbedingungen";
