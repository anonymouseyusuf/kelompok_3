<?php

$lang["type id"]   = "প্রকারভেদ আইডি";
$lang["user type"] = "ব্যবহারকারী প্রকারভেদ";
$lang["address"]   = "ঠিকানা";
$lang["change password"]   = "পাসওয়ার্ড পরিবর্তন";


