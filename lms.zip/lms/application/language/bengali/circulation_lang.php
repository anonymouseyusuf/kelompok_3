<?php
$lang["circulation"] 		 	= "বইয়ের সঞ্চলন";
$lang["circulation settings"] 	= "সঞ্চলন সেটিংস";
$lang["issue and return"] 		= "বই ইস্যু করুন বা ফেরত নিন";
$lang["issue & return"] 		= "বই ইস্যু করুন বা ফেরত নিন";
$lang["circulation list"] 		= "সঞ্চলন তালিকা";
$lang['issue limit - days'] 	= 'ইস্যু সীমা (দিন)';
$lang['issue limit - books'] 	= 'ইস্যু সীমা (বই)';
$lang['fine per day'] 			= 'দিন প্রতি জরিমানা';
$lang['issue'] 					= 'ইস্যু করুন';
$lang['new issue'] 				= 'নতুন করে বই ইস্যু করুন';
$lang['return'] 				= 'ফেরত নিন';
$lang["fine"] 				    = "জরিমানা";
$lang["penalty"] 				= "জরিমানা";

$lang['issue from date'] = "ইস্যু - তারিখ থেকে";
$lang['issue date'] = "ইস্যু করার তারিখ";
$lang['expire from date'] = "মেয়াদউর্তীন্ন - তারিখ থেকে";
$lang['issue to date'] = "ইস্যু - তারিখ পর্যন্ত";
$lang['expire to date'] = "মেয়াদউর্তীন্ন - তারিখ পর্যন্ত";
$lang['expiry date'] = "মেয়াদউর্তীন্ন হওয়ার তারিখ";
$lang['return date'] = "ফেরত দেওয়ার তারিখ";
$lang['return from date'] = "ফেরত দেওয়ার তারিখ হতে";
$lang['return from to'] = "ফেরত দেওয়ার তারিখ পর্যন্ত";

$lang["member search panel"]="সদস্য খুঁজুন";
$lang["member ID/name"]="সদস্যের আইডি নং/নাম";
$lang["book ID/name"]="বই এর আইডি নং/শিরোনাম";
$lang["current circulation"]="বর্তমান সঞ্চলন";

$lang['issued'] = "ইস্যুকৃত বই";
$lang['returned'] = "ফেরত দেওয়া বই";
$lang['expired and returned'] = "মেয়াদউর্তীন্ন হওয়ার পর ফেরত দেওয়া বই";
$lang['expired & returned'] = "মেয়াদউর্তীন্ন হওয়ার পর ফেরত দেওয়া বই";
$lang['expired and not returned'] = "মেয়াদউর্তীন্ন কিন্তু ফেরত না দেওয়া বই";
$lang['expired & not returned'] = "মেয়াদউর্তীন্ন কিন্তু ফেরত না দেওয়া বই";



