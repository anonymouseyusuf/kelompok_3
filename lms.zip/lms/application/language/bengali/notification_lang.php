<?php

$lang["SMS Gateway"] = "SMS Gateway";
$lang["Auth ID / Username"] = "Auth ID / Username";
$lang["Auth Token / Password"] = "Auth Token / Password";
$lang["Phone Number/ Mask"] = "Phone Number/ Mask";
$lang["API ID (Clickatell only)"] = "API ID - শুধুমাত্র Clickatell এর জন্য";

$lang['SMTP Host'] = "SMTP Host";
$lang['SMTP Port'] = "SMTP Port";
$lang['SMTP User'] = "SMTP User";
$lang['SMTP Password'] = "SMTP Password";


$lang["send notification to delayed members"] = "বিলম্বকৃত সদস্যদের বিজ্ঞপ্তি পাঠান";
$lang["send notification"] = "বিজ্ঞপ্তি পাঠান";
$lang["notification type"] = "বিজ্ঞপ্তির ধরন";
$lang["sending, please wait..."] = "পাঠানো হচ্ছে, অনুগ্রহ করে অপেক্ষা করুন...";
$lang["send sms/email notification"] = "SMS / ইমেইল বিজ্ঞপ্তি পাঠান ";

// added
$lang["message subject"] 			= "বার্তার বিষয়";
$lang["message"] 					= "বার্তা";
$lang["notification"] 			    = "বিজ্ঞপ্তি";
$lang["only notification"] 			= "শুধুমাত্র বিজ্ঞপ্তি";
$lang["email and notification"] 	= "ইমেইল এবং বিজ্ঞপ্তি";
$lang["SMS and notification"] 		= "SMS এবং বিজ্ঞপ্তি";




