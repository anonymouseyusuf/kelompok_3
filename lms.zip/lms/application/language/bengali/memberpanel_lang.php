<?php
$lang["my circulation history"] = "আমার বই সঞ্চলন সমূহ";
$lang["my requested books"] = "আমার অনুরোধকৃত বই সমূহ";
$lang["my notifications"] = "আমার বিজ্ঞপ্তি সমূহ";
$lang["request new book"] = "বইয়ের জন্য অনূরোধ করুন";
$lang["received at"] = "পৌছায়";
$lang["is returned"] = "ফেরত নেওয়া হয়েছে?"; // for admin panel actually
