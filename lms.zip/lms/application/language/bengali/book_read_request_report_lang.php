<?php
$lang["read - number of times"] = "পড়া হয়েছে - এত বার";
$lang["last read at"] = "সর্বশেষ পড়ার তারিখ";
$lang["member name"] = "সদস্যের নাম";
$lang["notification report"] = "বিজ্ঞপ্তির প্রতিবেদন";
$lang["memberwise fine report"] = "সদস্যের জরিমানা প্রতিবেদন";
$lang["reject request"]="অনুরোধ অগ্রাহ্য করুন";
$lang["cause of rejection"]="অগ্রাহ্য করার কারন";






