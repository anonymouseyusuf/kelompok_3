<?php

// admin sidebar
$lang["dashboard"] 				= "ড্যাশবোর্ড";
$lang["general settings"] 		= "সাধারণ সেটিংস";
$lang["books"] 					= "বই";
$lang["book categories"] 		= "বইয়ের শ্রেণীবিভাগ";
$lang["member"] 		 		= "সদস্য";
$lang["members"] 		 		= "সদস্যগণ";
$lang["member types"] 			= "সদস্যের প্রকারভেদ";
$lang['notification']			= 'বিজ্ঞপ্তি';
$lang['SMS settings']			= 'SMS সেটিংস';
$lang['email SMTP settings']	= 'ইমেইল SMTP সেটিংস';
$lang["notify delayed members"] = "বিলম্বকৃত সদস্যদের অবহিত করুন";
$lang["circulation"] 		 	= "বইয়ের সঞ্চলন";
$lang["circulation settings"] 	= "সঞ্চলন সেটিংস";
$lang["issue & return"] 		= "বই ইস্যু এবং ফেরত ";
$lang["daily read books"] 		= "দৈনিক পড়া বই";
$lang["requested books"] 		= "অনুরোধকৃত বই";
$lang["report"] 				= "প্রতিবেদন";
$lang["fine report"] 			= "জরিমানা প্রতিবেদন";
$lang["notification report"] 	= "বিজ্ঞপ্তি প্রতিবেদন";

$lang["generate member ID"] 	= "সদস্যগণের আইডি তৈরি করুন";
