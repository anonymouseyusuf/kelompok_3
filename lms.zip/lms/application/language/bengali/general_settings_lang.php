<?php

// general settings
$lang["institute name"] = "প্রতিষ্ঠানের নাম";
$lang["institute address"] = "প্রতিষ্ঠানের ঠিকানা";
$lang["institute email"] = "প্রতিষ্ঠানের ইমেইল";
$lang["institute phone / mobile"] = "প্রতিষ্ঠানের ফোন/মোবাইল ফোন";
$lang["logo"] = "প্রতিষ্ঠানের লোগো";
$lang["favicon"] = "ফেভিকন";
$lang["language"] = "ভাষা";
$lang["time zone"] = "সময় অঞ্চল";
$lang["currency"] = "মুদ্রা";
$lang["terms and conditions"] = "ব্যবহারের শর্তাবলী";
