<?php
$lang["my circulation history"] = "mijn bloedsomloop geschiedenis";
$lang["my requested books"] = "mijn gevraagde boeken";
$lang["my notifications"] = "mijn meldingen";
$lang["request new book"] = "aanvragen nieuw boek";
$lang["received at"] = "ontvangen op";
$lang["is returned"] = "geretourneerd"; // for admin panel actually
