<?php
$lang["read - number of times"] = "lezen - aantal keren";
$lang["last read at"] = "laatst gelezen op";
$lang["member name"] = "lid naam";
$lang["notification report"] = "notificatieverslag";
$lang["memberwise fine report"] = "lid straf rapport";
$lang["reject request"]="verzoek af te wijzen";
$lang["cause of rejection"]="oorzaak van de afwijzing";






