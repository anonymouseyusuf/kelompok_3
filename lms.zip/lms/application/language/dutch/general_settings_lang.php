<?php

// general settings
$lang["institute name"] = "naam van het instituut";
$lang["institute address"] = "instituut Adres";
$lang["institute email"] = "Instituut Email";
$lang["institute phone / mobile"] = "Instituut Telefoon / Mobiel";
$lang["logo"] = "Logo";
$lang["favicon"] = "favicon";
$lang["language"] = "taal";
$lang["time zone"] = "Tijdzone";
$lang["currency"] = "Valuta";
$lang["terms and conditions"] = "voorwaarden";
