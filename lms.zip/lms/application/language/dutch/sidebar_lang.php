<?php

// admin sidebar
$lang["dashboard"] 				= "dashboard";
$lang["general settings"] 		= "Algemene instellingen";
$lang["books"] 					= "boeken";
$lang["book categories"] 		= "categorieën boek";
$lang["member"]  				= "lid";
$lang["members"] 		 		= "leden";
$lang["member types"] 			= "types lid";
$lang['notification']			= "kennisgeving";
$lang['SMS settings']			= "SMS-instellingen";
$lang['email SMTP settings']	= "e-mail SMTP-instellingen";
$lang["notify delayed members"]= "melden vertraagde leden";
$lang["circulation"] 		 	= "circulatie";
$lang["circulation settings"] 	= "circulatie instellingen";
$lang["issue & return"] 		= "toewijzen en terugkeer";
$lang["daily read books"] 		= "dagelijks gelezen boeken";
$lang["requested books"] 		= "gevraagde boeken";
$lang["report"] 				= "rapport";
$lang["fine report"] 			= "boete rapport";
$lang["notification report"] 	= "notificatieverslag";

$lang["generate member ID"] 	= "genereren lid ID";
