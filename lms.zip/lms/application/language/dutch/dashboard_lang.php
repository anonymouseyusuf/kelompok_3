<?php

// dashboard
$lang['total issued books + Expired but not returned books'] = 
"totaal aantal uitgegeven boeken + Verlopen maar niet teruggegeven boeken";

$lang['total issued'] = "totale geplaatste";
$lang['expired but not returned'] = "verlopen, maar niet terug";
$lang['overall report'] = "algemeen verslag";
$lang['total number of books'] = "totaal aantal boeken";
$lang['total number of issued books'] = "totaal aantal uitgegeven boeken";
$lang['total number of members'] = "totale aantal leden";
$lang["today's report"] = "verslag van vandaag";
$lang["today's added books"] = "vandaag toegevoegd boeken";
$lang["today's issued books"] = "vandaag uitgegeven boeken";
$lang["today's returned books"] = "vandaag teruggekeerd boeken";
$lang["today's added members"] = "vandaag toegevoegd leden";
$lang["this month's added book"] = "toegevoegd boek deze maand";
$lang["current month's report"] = "verslag van de huidige maand";
$lang["this month's issued book"] = "geplaatste boek deze maand";
$lang["this month's returned book"] = "terug boek deze maand";

$lang["this month's added member"] = "toegevoegd lid van deze maand"; 

$lang["issued and returned report for last 12 months"] =
"uitgegeven en keerde rapport voor de laatste 12 maanden";
$lang["more information"] = "meer informatie";


/*morris*/
$lang['number total returned'] = "nummer total return";
$lang['number total issued'] = "aantal totale geplaatste";


