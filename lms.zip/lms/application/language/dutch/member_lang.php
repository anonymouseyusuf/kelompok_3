<?php

$lang["type id"]   = "soort id";
$lang["user type"] = "gebruikerstype";
$lang["address"]   = "adres";
$lang["change password"]   = "verander wachtwoord";


