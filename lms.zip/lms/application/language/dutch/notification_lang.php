<?php

$lang["SMS Gateway"] = "SMS Gateway";
$lang["Auth ID / Username"] = "Auth ID / Username";
$lang["Auth Token / Password"] = "Auth Token / Password";
$lang["Phone Number/ Mask"] = "Phone Number/ Mask";
$lang["API ID (Clickatell only)"] = "API_ID (Clickatell alleen)";

$lang['SMTP Host'] = "SMTP Host";
$lang['SMTP Port'] = "SMTP Port ";
$lang['SMTP User'] = "SMTP User";
$lang['SMTP Password'] = "SMTP Password";


$lang["send notification to delayed members"] = "send notification to delayed members";
$lang["send notification"] = "stuur bericht";
$lang["notification type"] = "meldingstype";
$lang["sending, please wait..."] = "verzenden, even geduld ...";


$lang["send sms/email notification"] = "stuur sms / e-mail notificatie";


$lang["message subject"] 			= "Bericht Onderwerp";
$lang["message"] 					= "bericht";
$lang["notification"] 			    = "kennisgeving";
$lang["only notification"] 			= "alleen melding";
$lang["email and notification"] 	= "e-mail en aanmelding";
$lang["SMS and notification"] 		= "SMS en aanmelding";




