<?php

// general settings
$lang["institute name"] = "nombre del Instituto";
$lang["institute address"] = "Instituto Dirección";
$lang["institute email"] = "Instituto Email";
$lang["institute phone / mobile"] = "Instituto Teléfono / Móvil";
$lang["logo"] = "Logo";
$lang["favicon"] = "favicon";
$lang["language"] = "idioma";
$lang["time zone"] = "Zona horaria";
$lang["currency"] = "Moneda";
$lang["terms and conditions"] = "términos y Condiciones";
