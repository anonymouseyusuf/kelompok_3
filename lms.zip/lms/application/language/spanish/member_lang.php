<?php

$lang["type id"]   = "tipo de Identificación";
$lang["user type"] = "tipo de usuario";
$lang["address"]   = "dirección";
$lang["change password"]   = "cambiar la contraseña";


