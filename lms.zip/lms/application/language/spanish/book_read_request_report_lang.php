<?php
$lang["read - number of times"] = "leer - número de veces";
$lang["last read at"] = "última lectura en";
$lang["member name"] = "Nombre del miembro";
$lang["notification report"] = "informe de notificación";
$lang["memberwise fine report"] = "miembro de informe pena";
$lang["reject request"]="rechazar la solicitud";
$lang["cause of rejection"]="causa de rechazo";






