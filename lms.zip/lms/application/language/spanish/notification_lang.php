<?php

$lang["SMS Gateway"] = "SMS Gateway";
$lang["Auth ID / Username"] = "Auth ID / Username";
$lang["Auth Token / Password"] = "Auth Token / Password";
$lang["Phone Number/ Mask"] = "Phone Number/ Mask";
$lang["API ID (Clickatell only)"] = "API_ID (Clickatell solamente)";

$lang['SMTP Host'] = "SMTP Host";
$lang['SMTP Port'] = "SMTP Port ";
$lang['SMTP User'] = "SMTP User";
$lang['SMTP Password'] = "SMTP Password";


$lang["send notification to delayed members"] = "enviar una notificación a los miembros retardados";
$lang["send notification"] = "Enviar notificación";
$lang["notification type"] = "tipo de notificación";
$lang["sending, please wait..."] = "enviando, por favor espere ...";


$lang["send sms/email notification"] = "enviar sms notificación / email";


$lang["message subject"] 			= "Asunto del mensaje";
$lang["message"] 					= "mensaje";
$lang["notification"] 			    = "notificación";
$lang["only notification"] 			= "única notificación";
$lang["email and notification"] 	= "correo electrónico y la notificación";
$lang["SMS and notification"] 		= "SMS y notificación";




