<?php

// admin sidebar
$lang["dashboard"] 				= "tablero de instrumentos";
$lang["general settings"] 		= "Configuración general";
$lang["books"] 					= "libros";
$lang["book categories"] 		= "categorías de libros";
$lang["member"]  				= "miembro";
$lang["members"] 		 		= "miembros";
$lang["member types"] 			= "tipos de miembro";
$lang['notification']			= "notificación";
$lang['SMS settings']			= "configuración de SMS";
$lang['email SMTP settings']	= "configuración SMTP de correo electrónico";
$lang["notify delayed members"]= "notificar a los miembros atrasados";
$lang["circulation"] 		 	= "circulación";
$lang["circulation settings"] 	= "ajustes de circulación";
$lang["issue & return"] 		= "tema y retorno";
$lang["daily read books"] 		= "libros de lectura diaria";
$lang["requested books"] 		= "libros solicitados";
$lang["report"] 				= "informe";
$lang["fine report"] 			= "pena de informe";
$lang["notification report"] 	= "informe de notificación";

$lang["generate member ID"] 	= "generar identificación de miembro";
