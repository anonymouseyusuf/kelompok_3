<?php
$lang["circulation"] 		 	= "circulación";
$lang["circulation settings"] 	= "ajustes de circulación";
$lang["issue and return"] 		= "emisión y retorno";
$lang["issue & return"] 		= "tema y retorno";
$lang["circulation list"] 		= "lista de circulación";
$lang['issue limit - days'] 	= 'límite de emisión - día';
$lang['issue limit - books'] 	= 'límite de emisión - libros';
$lang['fine per day'] 			= 'bien por día';
$lang['issue'] 					= 'asignar';
$lang['new issue'] 				= 'nueva edición';
$lang['return'] 				= 'regreso';
$lang["fine"] 				    = "multa";
$lang["penalty"] 				= "pena";

$lang['issue from date'] = "tema desde la fecha";
$lang['issue date'] = "fecha de asunto";
$lang['expire from date'] = "expirará partir de la fecha";
$lang['issue to date'] = "tema hasta la fecha";
$lang['expire to date'] = "expirará al día";
$lang['expiry date'] = "fecha de caducidad";
$lang['return date'] = "Fecha de regreso";
$lang['return from date'] = "volver desde la fecha";
$lang['return from to'] = "volver de a";

$lang["member search panel"]="panel de búsqueda de miembros";
$lang["member ID/name"]="identificación de miembro / Nombre";
$lang["book ID/name"]="libro Identificación / Nombre";
$lang["current circulation"]="circulación de corriente";

$lang['issued'] = "emitido";
$lang['returned'] = "regresado";
$lang['expired and returned'] = "caducado y regresó";
$lang['expired & returned'] = "expirado y devuelto";
$lang['expired and not returned'] = "expirado y no devueltos";
$lang['expired & not returned'] = "expirado y no devueltos";



