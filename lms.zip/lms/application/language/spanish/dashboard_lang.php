<?php

// dashboard
$lang['total issued books + expired but not returned books'] = 
"total de libros emitidos + libros vencidos pero no devueltos";

$lang['total issued'] = "expedida total";
$lang['expired but not returned'] = "caducado, pero no regresó";
$lang['overall report'] = "informe general";
$lang['total number of books'] = "número total de libros";
$lang['total number of issued books'] = "número total de libros publicados";
$lang['total number of members'] = "número total de miembros";
$lang["today's report"] = "el informe de hoy";
$lang["today's added books"] = "libros añadidos de hoy";
$lang["today's issued books"] = "libros publicados de hoy";
$lang["today's returned books"] = "libros devueltos de hoy";
$lang["today's added members"] = "miembros actuales añadidas";
$lang["this month's added book"] = "libro agregado de este mes";
$lang["current month's report"] = "el informe del mes actual";
$lang["this month's issued book"] = "libro número de este mes";
$lang["this month's returned book"] = "libro de regresar de este mes";

$lang["this month's added member"] = "miembro agregado de este mes"; 


$lang["issued and returned report for last 12 months"] = "informe emitido y devuelto para últimos 12 meses";
$lang["more information"] = "más información";

/*morris*/
$lang['number total returned'] = "número de rentabilidad total";
$lang['number total issued'] = "número total emitido";

