<?php
$lang["my circulation history"] = "mi historial de circulación";
$lang["my requested books"] = "mis libros solicitados";
$lang["my notifications"] = "mis notificaciones";
$lang["request new book"] = "solicitar nuevo libro";
$lang["received at"] = "recibida en";
$lang["is returned"] = "se devuelve"; // for admin panel actually
