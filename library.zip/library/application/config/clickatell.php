<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['clickatell_username']  = '';
$config['clickatell_password']  = '';
$config['clickatell_api_id']    = '';
$config['clickatell_from_no']   = 'CodeIgniter';
